package com.itouch27.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import android.content.pm.ServiceInfo

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val channel = "itouch27_service"

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(channel, "iTouch 27 controls", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channel)
            .setContentTitle("iTouch 27 is active")
            .setContentText("Floating assistive controls are running")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(27, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(27, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun glass(radius: Float = 48f) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius
        setColor(0xE91C2035.toInt())
        setStroke(2, 0x887F79D9.toInt())
    }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "✦"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = glass(100f); elevation = 12f
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = b
        val p = params(58, 58).apply {
            gravity = Gravity.TOP or Gravity.START; x = 18; y = 260
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true
                        p.x=ox+dx; p.y=oy+dy; wm.updateViewLayout(b,p); return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); return true }
                }; return false
            }
        })
        wm.addView(b, p)
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(18,16,18,16); background=glass(30f)
        }
        box.addView(TextView(this).apply {
            text="iTouch 27"; textSize=21f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
        })
        val close = Button(this).apply { text="বন্ধ"; setOnClickListener { hidePanel() } }
        box.addView(close)
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        addRow(box, "Volume −", "Volume +", {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
        }, {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
        })
        addAction(box, "Brightness −", "Brightness +") { up ->
            if (Settings.System.canWrite(this)) {
                val cur=Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 120)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                    (cur + if(up) 25 else -25).coerceIn(10,255))
            } else startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        addRow(box, "Home", "Back", { TouchAccessibilityService.runAction(AccessibilityAction.HOME) },
            { TouchAccessibilityService.runAction(AccessibilityAction.BACK) })
        addRow(box, "Recent Apps", "Notifications",
            { TouchAccessibilityService.runAction(AccessibilityAction.RECENTS) },
            { TouchAccessibilityService.runAction(AccessibilityAction.NOTIFICATIONS) })
        addRow(box, "Quick Settings", "Power Menu",
            { TouchAccessibilityService.runAction(AccessibilityAction.QUICK_SETTINGS) },
            { TouchAccessibilityService.runAction(AccessibilityAction.POWER) })
        addRow(box, "Lock Screen", "Screenshot",
            { TouchAccessibilityService.runAction(AccessibilityAction.LOCK) },
            { TouchAccessibilityService.runAction(AccessibilityAction.SCREENSHOT) })
        addRow(box, "Wi-Fi Settings", "Bluetooth Settings",
            { openSettings(Settings.ACTION_WIFI_SETTINGS) },
            { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) })
        panel=box
        val p=params(290, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity=Gravity.CENTER
        }
        wm.addView(box,p)
    }

    private fun addRow(root: LinearLayout, a: String, b: String, fa:()->Unit, fb:()->Unit) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf(a to fa,b to fb).forEach { (s,f) ->
            row.addView(Button(this).apply { text=s; isAllCaps=false; textSize=11f; setOnClickListener { f() } },
                LinearLayout.LayoutParams(0,54,1f))
        }; root.addView(row)
    }
    private fun addAction(root: LinearLayout,a:String,b:String,f:(Boolean)->Unit) =
        addRow(root,a,b,{f(false)},{f(true)})
    private fun openSettings(action:String) {
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    private fun hidePanel() { panel?.let { wm.removeView(it) }; panel=null }
    override fun onDestroy() {
        hidePanel(); bubble?.let { wm.removeView(it) }; bubble=null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
