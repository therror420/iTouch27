package com.itouch27.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 13, 27)
    private val accent = Color.rgb(145, 130, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 42, 24, 24); setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "iTouch 27"; textSize = 32f; setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "Liquid Glass • Assistive Controls"; textSize = 14f
            setTextColor(0xFFB9B5D2.toInt()); setPadding(0, 4, 0, 24)
        })
        root.addView(TextView(this).apply {
            text = "প্রথমবার ব্যবহারের আগে নিচের অনুমতিগুলো চালু করুন।"
            textSize = 15f; setTextColor(Color.WHITE); setPadding(0, 0, 0, 18)
        })
        addButton(root, "১. Floating button অনুমতি", accent) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addButton(root, "২. Accessibility চালু করুন", accent) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(root, "৩. Brightness নিয়ন্ত্রণের অনুমতি", accent) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        addButton(root, "৪. Floating Assistive Touch চালু করুন", 0xFF5CDBB3.toInt()) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "আগে Floating button অনুমতি দিন", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, FloatingService::class.java))
                Toast.makeText(this, "iTouch 27 চালু হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }
        addButton(root, "Floating button বন্ধ করুন", 0xFFEA7890.toInt()) {
            stopService(Intent(this, FloatingService::class.java))
        }
        root.addView(TextView(this).apply {
            text = "নোট: Home, Back, Recents, Lock ও Screenshot-এর জন্য Accessibility Service প্রয়োজন। Android/ফোন নির্মাতার সীমাবদ্ধতায় Restart-এর পর স্বয়ংক্রিয় চালু হওয়া নিশ্চিত নয়।"
            textSize = 12f; setTextColor(0xFFB9B5D2.toInt()); setPadding(0, 22, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addButton(root: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply {
            text = label; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            isAllCaps = false; textSize = 14f; setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 58).apply {
            bottomMargin = 10
        })
    }
}
