package com.itouch27.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 12, 25)
    private val card = Color.rgb(25, 30, 49)
    private val purple = Color.rgb(139, 111, 255)
    private val aqua = Color.rgb(62, 205, 190)
    private val prefs by lazy { getSharedPreferences("itouch", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var toggle: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun showDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(bg, Color.rgb(17, 22, 42))).apply { cornerRadius = dp(24).toFloat() }
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); addView(root) }
        root.addView(TextView(this).apply {
            text = "iTouch 27"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "LIQUID GLASS  •  ASSISTIVE CONTROLS"; textSize = 11f
            setTextColor(0xFFB8B5D5.toInt()); setPadding(0, dp(5), 0, dp(20))
        })
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = "তোমার ফোনের স্মার্ট কন্ট্রোল"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val lang = TextView(this).apply {
            text = "文  ভাষা"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = rounded(purple, 22); setPadding(dp(14), dp(9), dp(14), dp(9))
            setOnClickListener { chooseLanguage() }
        }
        top.addView(lang); root.addView(top); space(root, 16)

        val mainCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(17), dp(16), dp(17), dp(16))
            background = rounded(card, 22)
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val labelBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labelBox.addView(TextView(this).apply { text = "Assistive Touch"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
        status = TextView(this).apply { textSize = 12f; setTextColor(aqua); setPadding(0, dp(4), 0, 0) }
        labelBox.addView(status)
        row.addView(labelBox, LinearLayout.LayoutParams(0, -2, 1f))
        toggle = Switch(this).apply { isChecked = false; setOnCheckedChangeListener { _, checked -> if (checked) startTouch() else stopTouch() } }
        row.addView(toggle); mainCard.addView(row)
        mainCard.addView(TextView(this).apply { text = "✦"; textSize = 28f; setTextColor(purple); setPadding(0, dp(8), 0, 0) })
        root.addView(mainCard); space(root, 12)

        val grid1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid1.addView(featureCard("▦", "Custom Menu", "কন্ট্রোল সাজাও", purple) { showInfo("Custom Menu", "Quick controls কাস্টমাইজ করার অপশন পরবর্তী সংস্করণে যোগ হবে।") }, LinearLayout.LayoutParams(0, dp(112), 1f))
        grid1.addView(featureCard("◉", "Icon", "Floating icon বদলাও", aqua) { showInfo("Icon", "Floating button-এর আইকন বেছে নেওয়ার অপশন পরবর্তী সংস্করণে যোগ হবে।") }, LinearLayout.LayoutParams(0, dp(112), 1f).apply { leftMargin = dp(10) })
        root.addView(grid1); space(root, 10)
        val grid2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid2.addView(featureCard("⚙", "Settings", "অনুমতি ও পছন্দ", 0xFFBE91FF.toInt()) { showSettings() }, LinearLayout.LayoutParams(0, dp(112), 1f))
        grid2.addView(featureCard("ⓘ", "About", "সংস্করণ ও সহায়তা", 0xFFFFB86B.toInt()) { showInfo("iTouch 27", "Liquid Glass Assistive Controls\nVersion 1.1") }, LinearLayout.LayoutParams(0, dp(112), 1f).apply { leftMargin = dp(10) })
        root.addView(grid2); space(root, 18)
        root.addView(TextView(this).apply {
            text = "দ্রুত নিয়ন্ত্রণ"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
        }); space(root, 8)
        root.addView(TextView(this).apply {
            text = "Floating button চালু হলে Volume, Brightness ও প্রয়োজনীয় শর্টকাট এক জায়গায় পাবে।\n\nনোট: কিছু কন্ট্রোলের জন্য Android Accessibility ও প্রয়োজনীয় সিস্টেম অনুমতি লাগবে।"
            textSize = 13f; setTextColor(0xFFB9BED2.toInt()); setPadding(dp(15), dp(14), dp(15), dp(14)); background = rounded(card, 18)
        })
        setContentView(scroll)
        refreshStatus()
    }

    private fun featureCard(icon: String, title: String, subtitle: String, tint: Int, action: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(10), dp(12)); background = rounded(card, 20)
            setOnClickListener { action() }
            addView(TextView(this@MainActivity).apply { text = icon; textSize = 22f; setTextColor(tint) })
            addView(TextView(this@MainActivity).apply { text = title; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setPadding(0, dp(4), 0, 0) })
            addView(TextView(this@MainActivity).apply { text = subtitle; textSize = 10f; setTextColor(0xFFB8BBD0.toInt()); setPadding(0, dp(3), 0, 0) })
        }
    }

    private fun showSettings() {
        val items = arrayOf("Floating button অনুমতি", "Accessibility চালু করুন", "Brightness নিয়ন্ত্রণের অনুমতি", "ভাষা পরিবর্তন")
        AlertDialog.Builder(this).setTitle("Settings").setItems(items) { _, which -> when (which) {
            0 -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            1 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            2 -> startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            3 -> chooseLanguage()
        } }.setNegativeButton("বন্ধ", null).show()
    }

    private fun chooseLanguage() {
        val langs = arrayOf("Default", "বাংলা", "English", "العربية", "हिन्दी")
        AlertDialog.Builder(this).setTitle("Select Language").setSingleChoiceItems(langs, prefs.getInt("language", 1)) { dialog, which ->
            prefs.edit().putInt("language", which).apply(); dialog.dismiss()
            Toast.makeText(this, if (which == 1) "বাংলা নির্বাচিত" else "Language selected", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun startTouch() {
        if (!Settings.canDrawOverlays(this)) {
            toggle.isChecked = false
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "আগে Floating button অনুমতি দিন", Toast.LENGTH_LONG).show(); return
        }
        startForegroundService(Intent(this, FloatingService::class.java)); refreshStatus()
    }
    private fun stopTouch() { stopService(Intent(this, FloatingService::class.java)); refreshStatus() }
    private fun refreshStatus() {
        val enabled = toggle.isChecked
        status.text = if (enabled) "● চালু আছে" else "○ বন্ধ আছে"
    }
    private fun showInfo(title: String, message: String) { AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("ঠিক আছে", null).show() }
    private fun addButton(root: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply { text = label; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(color); isAllCaps = false; setOnClickListener { action() } }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(8) })
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), 0x33FFFFFF) }
    private fun space(root: LinearLayout, h: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
