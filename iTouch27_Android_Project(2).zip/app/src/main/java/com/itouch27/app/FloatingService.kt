package com.itouch27.app

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import android.content.pm.ServiceInfo
import kotlin.math.max

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val channel = "itouch27_service"

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(channel, "iTouch 27 controls", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channel)
            .setContentTitle("iTouch 27 is active")
            .setContentText("Floating assistive controls are running")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(27, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(27, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun glass(radius: Float = 48f, color: Int = 0xD9232635.toInt(), stroke: Int = 0x667F849E) =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(color)
            setStroke(2, stroke)
        }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "✦"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = glass(100f, 0xE9232440.toInt(), 0xAA9D91FF.toInt()); elevation = 12f
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = b
        val p = params(58, 58).apply {
            gravity = Gravity.TOP or Gravity.START; x = 18; y = 260
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true
                        p.x=ox+dx; p.y=oy+dy; wm.updateViewLayout(b,p); return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); return true }
                }; return false
            }
        })
        wm.addView(b, p)
    }

    private fun showPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = glass(34f, 0xE8171A27.toInt(), 0x887D83A5.toInt())
            elevation = dp(18).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "iTouch 27\nLIQUID GLASS CONTROL CENTER"
            textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(makeButton("×", 0xFF3A3D4B.toInt(), 20f) { hidePanel() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        outer.addView(header)
        addSpace(outer, 12)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val quickRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        quickRow1.addView(makeButton("⟳", 0xFF3A3E4C.toInt(), 22f) { TouchAccessibilityService.runAction(AccessibilityAction.QUICK_SETTINGS) }, weighted())
        quickRow1.addView(makeButton("▣", 0xFF3A3E4C.toInt(), 22f) { TouchAccessibilityService.runAction(AccessibilityAction.RECENTS) }, weighted())
        left.addView(quickRow1)
        addSpace(left, 8)
        left.addView(makeButton("◉   Focus", 0xFF354D5A.toInt(), 14f) { openSettings(Settings.ACTION_DISPLAY_SETTINGS) }, LinearLayout.LayoutParams(dp(150), dp(58)))
        addSpace(left, 8)
        val quickRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        quickRow2.addView(makeButton("⌂", 0xFF3A3E4C.toInt(), 22f) { TouchAccessibilityService.runAction(AccessibilityAction.HOME) }, weighted())
        quickRow2.addView(makeButton("‹", 0xFF3A3E4C.toInt(), 22f) { TouchAccessibilityService.runAction(AccessibilityAction.BACK) }, weighted())
        left.addView(quickRow2)
        top.addView(left, LinearLayout.LayoutParams(0, dp(210), 1f))

        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val maxVolume = max(1, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
        val currentVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val volumeSlider = VerticalLevelView(this, 0xFFB69AFF.toInt(), 0xFF514078.toInt(), currentVolume * 100 / maxVolume) { value ->
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (value * maxVolume / 100).coerceIn(0, maxVolume), 0)
        }
        val brightnessNow = if (Settings.System.canWrite(this))
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 120) * 100 / 255 else 50
        val brightnessSlider = VerticalLevelView(this, 0xFF63E3D0.toInt(), 0xFF286B70.toInt(), brightnessNow) { value ->
            if (Settings.System.canWrite(this)) {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, value * 255 / 100)
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        top.addView(sliderColumn("☼", "LIGHT", brightnessSlider), LinearLayout.LayoutParams(dp(58), dp(210)))
        top.addView(sliderColumn("◖", "SOUND", volumeSlider), LinearLayout.LayoutParams(dp(58), dp(210)))
        outer.addView(top)
        addSpace(outer, 12)

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rows = listOf(
            listOf("▣" to "Screenshot", "☷" to "Notifications", "ϟ" to "Flashlight"),
            listOf("⌂" to "Home", "‹" to "Back", "▤" to "Recent"),
            listOf("Wi-Fi" to "Wi-Fi", "ᛒ" to "Bluetooth", "⏻" to "Power")
        )
        rows.forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { (symbol, label) ->
                val action: () -> Unit = when(label) {
                    "Screenshot" -> {{ TouchAccessibilityService.runAction(AccessibilityAction.SCREENSHOT) }}
                    "Notifications" -> {{ TouchAccessibilityService.runAction(AccessibilityAction.NOTIFICATIONS) }}
                    "Flashlight" -> {{ openSettings(Settings.ACTION_SETTINGS) }}
                    "Home" -> {{ TouchAccessibilityService.runAction(AccessibilityAction.HOME) }}
                    "Back" -> {{ TouchAccessibilityService.runAction(AccessibilityAction.BACK) }}
                    "Recent" -> {{ TouchAccessibilityService.runAction(AccessibilityAction.RECENTS) }}
                    "Wi-Fi" -> {{ openSettings(Settings.ACTION_WIFI_SETTINGS) }}
                    "Bluetooth" -> {{ openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }}
                    else -> {{ TouchAccessibilityService.runAction(AccessibilityAction.POWER) }}
                }
                row.addView(makeButton("$symbol\n$label", 0xFF343847.toInt(), 12f, action),
                    LinearLayout.LayoutParams(0, dp(62), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            grid.addView(row)
        }
        outer.addView(grid)
        addSpace(outer, 5)
        outer.addView(TextView(this).apply {
            text = "টেনে Brightness ও Volume নিয়ন্ত্রণ করুন"
            textSize = 10f; gravity = Gravity.CENTER; setTextColor(0xFFB9BBD0.toInt())
        })

        panel = outer
        val p = params(dp(350), WindowManager.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.CENTER }
        wm.addView(outer, p)
    }

    private fun sliderColumn(icon: String, label: String, slider: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(3), 0, dp(3), 0)
            addView(TextView(this@FloatingService).apply {
                text = icon; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(-1, dp(25)))
            addView(slider, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(TextView(this@FloatingService).apply {
                text = label; textSize = 9f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(-1, dp(22)))
        }
    }

    private fun makeButton(text: String, color: Int, size: Float, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = size; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = glass(24f, color, 0x667F849E)
        setOnClickListener { action() }
        elevation = dp(3).toFloat()
    }

    private fun weighted() = LinearLayout.LayoutParams(0, dp(58), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
    private fun addSpace(root: LinearLayout, height: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, dp(height))) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun openSettings(action: String) {
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    private fun hidePanel() { panel?.let { wm.removeView(it) }; panel = null }
    override fun onDestroy() {
        hidePanel(); bubble?.let { wm.removeView(it) }; bubble = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}

private class VerticalLevelView(
    context: Context,
    private val fillColor: Int,
    private val trackColor: Int,
    initial: Int,
    private val onChange: (Int) -> Unit
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var progress = initial.coerceIn(0, 100)
    private val radius = 22f * resources.displayMetrics.density
    private val pad = 8f * resources.displayMetrics.density

    init { isClickable = true }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val top = pad
        val bottom = height - pad
        val track = RectF(cx - radius, top, cx + radius, bottom)
        paint.color = trackColor
        canvas.drawRoundRect(track, radius, radius, paint)
        val filledHeight = (bottom - top) * progress / 100f
        val fill = RectF(cx - radius, bottom - filledHeight, cx + radius, bottom)
        paint.color = fillColor
        canvas.drawRoundRect(fill, radius, radius, paint)
        paint.color = Color.WHITE
        paint.alpha = 235
        canvas.drawCircle(cx, bottom - filledHeight, radius * 0.72f, paint)
        paint.color = fillColor
        paint.textSize = 18f * resources.displayMetrics.density
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(if (progress > 50) "＋" else "−", cx, bottom - filledHeight + paint.textSize * 0.34f, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                val usable = (height - 2 * pad).coerceAtLeast(1f)
                progress = (((height - pad - event.y) / usable) * 100).toInt().coerceIn(0, 100)
                invalidate()
                onChange(progress)
                return true
            }
        }
        return true
    }
}
