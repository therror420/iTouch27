# iTouch 27 — Android Native Kotlin

iOS-inspired floating Assistive Touch controls for personal use.

## কী কী আছে
- Floating movable glass-style button and quick panel
- Media volume up/down
- Brightness up/down (WRITE_SETTINGS permission required)
- Home, Back, Recents, Notifications, Quick Settings, Power menu
- Lock screen and Screenshot (Android 9+; Accessibility permission)
- Wi-Fi and Bluetooth settings shortcuts
- Foreground service and best-effort restart receiver

## Build
1. কম্পিউটারে Android Studio (JDK 17 সহ) ইনস্টল করুন।
2. Android Studio থেকে এই `iTouch27` ফোল্ডারটি Open করুন।
3. Gradle Sync শেষ হলে Build > Build APK(s) নির্বাচন করুন।
4. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

## ফোনে চালু করা
1. APK ইনস্টল করে iTouch 27 খুলুন।
2. Floating button permission দিন।
3. Accessibility settings-এ গিয়ে iTouch 27 চালু করুন।
4. Brightness নিয়ন্ত্রণ চাইলে Modify system settings অনুমতি দিন।
5. অ্যাপে ফিরে “Floating Assistive Touch চালু করুন” চাপুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- Android-এর নিজস্ব নিরাপত্তা নীতির কারণে কিছু ডিভাইসে boot-এর পর সার্ভিস নিজে চালু নাও হতে পারে; Battery Optimization/Background restrictions-এ অনুমতি দিন এবং প্রয়োজন হলে অ্যাপ খুলে চালু করুন।
- Android সংস্করণ, নির্মাতার UI এবং অনুমতির ওপর নির্ভর করে Lock, Screenshot, Power menu ইত্যাদি কাজ করতে পারে।
- Volume control বর্তমানে Media stream নিয়ন্ত্রণ করে। Wi-Fi/Bluetooth বোতাম সরাসরি রেডিও toggle না করে সংশ্লিষ্ট Settings খোলে, কারণ আধুনিক Android-এ তৃতীয় পক্ষের অ্যাপের সরাসরি নিয়ন্ত্রণ সীমিত।
- এই প্রজেক্টে কোনো বিজ্ঞাপন, analytics বা account login নেই।
- Accessibility permission কেবল ব্যবহারকারীর নির্বাচিত system navigation action-এর জন্য ব্যবহৃত হয়; window content পড়া হয় না।
