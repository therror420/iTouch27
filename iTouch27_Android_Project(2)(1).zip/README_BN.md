# iTouch 27 — White Liquid Glass Edition

এটি iTouch 27-এর নতুন পরীক্ষামূলক Native Android/Kotlin সংস্করণ। ডিজাইনটি সাদা স্বচ্ছ গ্লাস, হালকা নীল/বেগুনি/মিন্ট আভা এবং আলাদা সেটিংস পেজের ওপর ভিত্তি করে তৈরি।

## নতুন UI
- সাদা স্বচ্ছ গ্লাস Dashboard
- আলাদা Settings, About, Custom Menu, Theme এবং Icon Studio পেজ
- Icon Studio-তে আইকন নির্বাচন, লাইভ প্রিভিউ এবং আকার নিয়ন্ত্রণ
- Glow, Neon, Soft Shadow, Gradient, Pulse ও Liquid Glass ইফেক্ট নির্বাচন
- Custom Menu থেকে কুইক কন্ট্রোল দেখানো/লুকানো
- Floating Control Center-এ সাদা গ্লাস কার্ড ও রঙিন Brightness/Volume স্লাইডার
- Screenshot নেওয়ার আগে Floating Panel ও Bubble সাময়িক লুকানো
- Floating service-এর চালু অবস্থা SharedPreferences-এ রাখা

## Build (GitHub Actions)
1. ZIP-এর ভেতরের সব ফাইল GitHub repository-র root-এ আপলোড করো (ফোল্ডারসহ)।
2. `.github/workflows/build.yml` ফাইলটি repository-তে আছে কিনা নিশ্চিত করো।
3. GitHub-এর Actions ট্যাবে `Build iTouch 27 APK` workflow চালাও।
4. সফল হলে `iTouch27-APK` Artifact ডাউনলোড করে ZIP extract করো।
5. `app-debug.apk` ফোনে ইনস্টল করো।

## প্রয়োজনীয় অনুমতি
- Floating button-এর জন্য Display over other apps
- Home/Back/Recent/Screenshot-এর জন্য Accessibility Service
- Brightness-এর জন্য Modify system settings
- Flashlight-এর জন্য ক্যামেরা/টর্চ অনুমতি (ডিভাইসভেদে সিস্টেম Quick Settings ব্যবহার করতে হতে পারে)

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি পরীক্ষামূলক সোর্স সংস্করণ; এই পরিবেশে Android SDK/Gradle ইনস্টল না থাকায় APK compile বা ফোনে পরীক্ষা করা হয়নি। GitHub Actions-এ build result যাচাই করতে হবে।
- Wi-Fi ও Bluetooth বাটন Android-এর সীমাবদ্ধতার কারণে সরাসরি radio toggle না করে Android Quick Settings প্যানেল খোলে।
- Screenshot বাটন Accessibility Service চালু থাকলে Android-এর Global Screenshot action ব্যবহার করে; সিস্টেম অনুমতি/ডিভাইস নীতির কারণে ব্যর্থ হতে পারে।
- Flashlight-এর জন্য runtime camera permission না থাকলে টর্চ কাজ নাও করতে পারে।
- আইকন ইফেক্ট নির্বাচন ও প্রিভিউ সংরক্ষণ করা হয়; সব অ্যানিমেশন ইফেক্ট এখনো Floating Bubble-এ প্রয়োগ করা হয়নি।
- Android-এর ব্যাটারি ব্যবস্থাপনা কিছু ফোনে ব্যাকগ্রাউন্ড সার্ভিস বন্ধ করতে পারে।
