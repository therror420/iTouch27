package com.itouch27.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED &&
            context.getSharedPreferences("itouch", Context.MODE_PRIVATE).getBoolean("enabled", false) &&
            Settings.canDrawOverlays(context)) {
            try {
                val service=Intent(context, FloatingService::class.java)
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service)
                else context.startService(service)
            } catch (_: Exception) { /* User can restart from the app if Android blocks boot start. */ }
        }
    }
}
