package com.itouch27.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

enum class AccessibilityAction { HOME, BACK, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, POWER, LOCK, SCREENSHOT }

class TouchAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onServiceConnected() { instance=this }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance=null
        return super.onUnbind(intent)
    }

    companion object {
        @Volatile private var instance: TouchAccessibilityService? = null
        fun runAction(action: AccessibilityAction) {
            val svc=instance
            if (svc == null) return
            val global = when(action) {
                AccessibilityAction.HOME -> GLOBAL_ACTION_HOME
                AccessibilityAction.BACK -> GLOBAL_ACTION_BACK
                AccessibilityAction.RECENTS -> GLOBAL_ACTION_RECENTS
                AccessibilityAction.NOTIFICATIONS -> GLOBAL_ACTION_NOTIFICATIONS
                AccessibilityAction.QUICK_SETTINGS -> GLOBAL_ACTION_QUICK_SETTINGS
                AccessibilityAction.POWER -> GLOBAL_ACTION_POWER_DIALOG
                AccessibilityAction.LOCK -> if (android.os.Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return
                AccessibilityAction.SCREENSHOT -> if (android.os.Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return
            }
            svc.performGlobalAction(global)
        }
    }
}
