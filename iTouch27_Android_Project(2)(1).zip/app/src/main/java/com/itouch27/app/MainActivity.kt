package com.itouch27.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("itouch", MODE_PRIVATE) }
    private val ink = Color.rgb(28, 38, 62)
    private val muted = Color.rgb(105, 119, 145)
    private val blue = Color.rgb(65, 123, 245)
    private val purple = Color.rgb(143, 103, 245)
    private val aqua = Color.rgb(65, 190, 180)
    private lateinit var page: LinearLayout
    private lateinit var serviceStatus: TextView
    private lateinit var serviceSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showDashboard(); if (prefs.getBoolean("enabled", false) && Settings.canDrawOverlays(this)) startForegroundService(Intent(this, FloatingService::class.java)) }
    override fun onResume() { super.onResume(); if (::serviceSwitch.isInitialized) refreshServiceState() }

    private fun base(title: String, subtitle: String? = null): ScrollView {
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(28)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFF8FBFF.toInt(), 0xFFEAF1FF.toInt(), 0xFFFDFEFF.toInt())) }
        val sc = ScrollView(this).apply { setBackgroundColor(0xFFF4F7FC.toInt()); addView(page) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(iconButton("‹") { showDashboard() }, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titles.addView(label(title, 23f, ink, true))
        if (subtitle != null) titles.addView(label(subtitle, 11f, muted, false))
        header.addView(titles); page.addView(header); gap(18)
        return sc
    }

    private fun showDashboard() {
        val sc = base("iTouch 27", "WHITE LIQUID GLASS • ASSISTIVE CONTROLS")
        val hero = glassCard().apply { setPadding(dp(18), dp(18), dp(18), dp(18)) }
        hero.addView(label("তোমার ফোনের স্মার্ট কন্ট্রোল", 18f, ink, true))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        details.addView(label("✦  Assistive Touch", 17f, ink, true))
        serviceStatus = label("পরীক্ষা করা হচ্ছে…", 12f, aqua, false); details.addView(serviceStatus)
        row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        serviceSwitch = Switch(this).apply { isChecked = prefs.getBoolean("enabled", false); setOnCheckedChangeListener { _, checked -> if (checked) startTouch() else stopTouch() } }
        row.addView(serviceSwitch); hero.addView(row); page.addView(hero); gap(14)
        val grid1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid1.addView(feature("▦", "কাস্টম মেনু", "কন্ট্রোল সাজাও", purple) { showCustomMenu() }, weight())
        grid1.addView(feature("◉", "আইকন স্টুডিও", "সাইজ ও ইফেক্ট", aqua) { showIconStudio() }, weight(true)); page.addView(grid1); gap(10)
        val grid2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid2.addView(feature("⚙", "সেটিংস", "অ্যাপ কাস্টমাইজ", blue) { showSettings() }, weight())
        grid2.addView(feature("ⓘ", "অ্যাপ সম্পর্কে", "তথ্য ও সংস্করণ", 0xFFE7A34C.toInt()) { showAbout() }, weight(true)); page.addView(grid2); gap(18)
        page.addView(label("দ্রুত নির্দেশনা", 18f, ink, true)); gap(8)
        page.addView(labelCard("Floating Button চালু করলে Volume, Brightness এবং প্রয়োজনীয় শর্টকাট এক জায়গায় পাবে। কিছু কন্ট্রোলের জন্য Android-এর Accessibility বা সিস্টেম অনুমতি প্রয়োজন হবে।"))
        setContentView(sc); refreshServiceState()
    }

    private fun showSettings() {
        val sc = base("সেটিংস", "iTouch 27 কাস্টমাইজেশন")
        menuRow("🎨", "চেহারা ও থিম", "সাদা গ্লাস ও রঙের আভা") { showTheme() }
        menuRow("🌐", "ভাষা", "বাংলা / English") { chooseLanguage() }
        menuRow("▦", "কন্ট্রোল মেনু", "কুইক বাটন সাজানো") { showCustomMenu() }
        menuRow("◉", "আইকন স্টুডিও", "আইকন সাইজ ও ইফেক্ট") { showIconStudio() }
        menuRow("☼", "Brightness অনুমতি", "স্ক্রিনের উজ্জ্বলতা নিয়ন্ত্রণ") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        menuRow("♧", "Floating অনুমতি", "অন্য অ্যাপের ওপর দেখানোর অনুমতি") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        menuRow("⌘", "Accessibility", "Home, Back ও Screenshot-এর জন্য") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        menuRow("ⓘ", "অ্যাপ সম্পর্কে", "সংস্করণ ও সহায়তা") { showAbout() }
        setContentView(sc)
    }

    private fun showTheme() {
        val sc = base("থিম ও রং", "নিজের পছন্দের গ্লাস রং বেছে নাও")
        listOf("সাদা স্বচ্ছ গ্লাস" to 0xFFF7FAFF.toInt(), "আকাশি নীল গ্লাস" to 0xFFDCEBFF.toInt(), "মিন্ট গ্লাস" to 0xFFDDF8F1.toInt(), "ল্যাভেন্ডার গ্লাস" to 0xFFECE3FF.toInt()).forEachIndexed { i, pair ->
            val v = glassCard().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14)); setOnClickListener { prefs.edit().putInt("theme", i).apply(); Toast.makeText(this@MainActivity, "থিম সংরক্ষণ হয়েছে", Toast.LENGTH_SHORT).show() } }
            val swatch = View(this).apply { background = rounded(pair.second, 18, 0x668A9BB8) }; v.addView(swatch, LinearLayout.LayoutParams(dp(46), dp(46)))
            v.addView(label(pair.first, 16f, ink, true).apply { setPadding(dp(14), 0, 0, 0) }); page.addView(v); gap(10)
        }; setContentView(sc)
    }

    private fun showIconStudio() {
        val sc = base("আইকন স্টুডিও", "আইকন নিজের মতো সাজাও")
        val preview = glassCard().apply { gravity = Gravity.CENTER; setPadding(dp(18), dp(25), dp(18), dp(25)) }
        val previewIcon = TextView(this).apply { text = prefs.getString("icon", "✦"); textSize = prefs.getInt("iconSize", 56).toFloat(); gravity = Gravity.CENTER; setTextColor(blue); background = rounded(0xDFFFFFFF.toInt(), 28, 0x887DA8E8) }
        preview.addView(previewIcon, LinearLayout.LayoutParams(dp(110), dp(110))); preview.addView(label("লাইভ প্রিভিউ", 12f, muted, false)); page.addView(preview); gap(14)
        page.addView(label("আইকন নির্বাচন", 17f, ink, true)); gap(8)
        val icons = listOf("✦", "⌂", "◉", "☼", "♫", "▣", "◆", "❖", "⚡", "●", "◈", "✧")
        val iconGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        icons.chunked(4).forEach { chunk ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { symbol -> r.addView(iconButton(symbol) { prefs.edit().putString("icon", symbol).apply(); previewIcon.text = symbol }, weight()) }
            iconGrid.addView(r); gap(6)
        }; page.addView(iconGrid); gap(14)
        page.addView(label("আইকনের আকার", 17f, ink, true))
        val sizeText = label("${prefs.getInt("iconSize", 56)} px", 13f, muted, false); page.addView(sizeText)
        val size = SeekBar(this).apply { max = 68; progress = (prefs.getInt("iconSize", 56) - 32).coerceIn(0, 68); setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { val v=p+32; previewIcon.textSize=v.toFloat(); sizeText.text="$v px"; prefs.edit().putInt("iconSize",v).apply() }; override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) }; page.addView(size); gap(14)
        page.addView(label("আইকন ইফেক্ট", 17f, ink, true)); gap(8)
        listOf("স্বচ্ছ গ্লাস", "Glow", "Neon", "Soft Shadow", "Gradient", "Pulse").forEach { effect ->
            val b = TextView(this).apply { text = "◉   $effect"; textSize=15f; setTextColor(ink); gravity=Gravity.CENTER_VERTICAL; setPadding(dp(16),0,dp(16),0); background=rounded(0xCCFFFFFF.toInt(),18,0x5589A6D4); setOnClickListener { prefs.edit().putString("effect",effect).apply(); Toast.makeText(this@MainActivity,"$effect নির্বাচন করা হয়েছে",Toast.LENGTH_SHORT).show() } }
            page.addView(b, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin=dp(8) })
        }
        val save = actionButton("পরিবর্তন সংরক্ষণ") { Toast.makeText(this,"আইকন সেটিংস সংরক্ষিত",Toast.LENGTH_SHORT).show(); if (prefs.getBoolean("enabled",false) && Settings.canDrawOverlays(this)) { stopService(Intent(this,FloatingService::class.java)); startForegroundService(Intent(this,FloatingService::class.java)) }; showDashboard() }; page.addView(save); setContentView(sc)
    }

    private fun showCustomMenu() {
        val sc = base("কাস্টম মেনু", "কন্ট্রোল প্যানেলে কোন আইকন থাকবে")
        val options = listOf("Wi-Fi", "Bluetooth", "Flashlight", "Screenshot", "Notifications", "Home", "Back", "Recent", "Power", "Focus")
        options.forEachIndexed { i, name ->
            val cb = CheckBox(this).apply { text = name; textSize=16f; setTextColor(ink); buttonTintList=android.content.res.ColorStateList.valueOf(blue); isChecked=prefs.getBoolean("menu_$i", true); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("menu_$i",checked).apply() } }
            val card=glassCard().apply { setPadding(dp(12),dp(7),dp(12),dp(7)); addView(cb) }; page.addView(card); gap(7)
        }; page.addView(actionButton("সংরক্ষণ") { showDashboard() }); setContentView(sc)
    }

    private fun showAbout() {
        val sc = base("অ্যাপ সম্পর্কে", "iTouch 27")
        val card=glassCard().apply { gravity=Gravity.CENTER; setPadding(dp(22),dp(26),dp(22),dp(26)) }
        card.addView(label("✦",52f,purple,true).apply { gravity=Gravity.CENTER }); card.addView(label("iTouch 27",26f,ink,true).apply { gravity=Gravity.CENTER }); card.addView(label("WHITE LIQUID GLASS • ASSISTIVE CONTROLS",10f,muted,false).apply { gravity=Gravity.CENTER }); card.addView(label("সংস্করণ 1.2 • পরীক্ষামূলক",13f,muted,false).apply { gravity=Gravity.CENTER; setPadding(0,dp(12),0,0) }); page.addView(card); gap(14)
        page.addView(labelCard("iTouch 27 হলো Android-এর জন্য একটি কাস্টম Assistive Touch ও Quick Control অ্যাপ। কিছু সুবিধা Android Accessibility এবং সিস্টেম অনুমতির ওপর নির্ভরশীল।")); setContentView(sc)
    }

    private fun chooseLanguage() { val a=arrayOf("বাংলা","English"); android.app.AlertDialog.Builder(this).setTitle("ভাষা নির্বাচন").setSingleChoiceItems(a,prefs.getInt("language",0)){d,w->prefs.edit().putInt("language",w).apply();d.dismiss();Toast.makeText(this,a[w],Toast.LENGTH_SHORT).show()}.setNegativeButton("বন্ধ",null).show() }

    private fun startTouch() {
        if (!Settings.canDrawOverlays(this)) { serviceSwitch.isChecked=false; startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))); Toast.makeText(this,"আগে Floating অনুমতি দিন",Toast.LENGTH_LONG).show(); return }
        prefs.edit().putBoolean("enabled",true).apply(); startForegroundService(Intent(this,FloatingService::class.java)); serviceStatus.text="● চালু আছে"
    }
    private fun stopTouch() { prefs.edit().putBoolean("enabled",false).apply(); stopService(Intent(this,FloatingService::class.java)); serviceStatus.text="○ বন্ধ আছে" }
    private fun refreshServiceState() { val on=FloatingService.isRunning && prefs.getBoolean("enabled",false) && Settings.canDrawOverlays(this); serviceSwitch.isChecked=on; serviceStatus.text=if(on) "● চালু আছে" else "○ বন্ধ আছে" }

    private fun feature(i:String,t:String,d:String,c:Int,action:()->Unit)=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(15),dp(10),dp(15)); background=rounded(0xDFFFFFFF.toInt(),22,0x668DA7CE); elevation=dp(5).toFloat(); setOnClickListener{action()}; addView(label(i,25f,c,true)); addView(label(t,15f,ink,true)); addView(label(d,10f,muted,false)) }
    private fun menuRow(i:String,t:String,d:String,action:()->Unit) { val r=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(14),dp(12),dp(12),dp(12)); background=rounded(0xDFFFFFFF.toInt(),20,0x558DA7CE); elevation=dp(2).toFloat(); setOnClickListener{action()} }; r.addView(label(i,25f,blue,true),LinearLayout.LayoutParams(dp(48),dp(48))); val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; col.addView(label(t,16f,ink,true)); col.addView(label(d,11f,muted,false)); r.addView(col,LinearLayout.LayoutParams(0,-2,1f)); r.addView(label("›",25f,muted,false)); page.addView(r); gap(9) }
    private fun glassCard()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=rounded(0xDFFFFFFF.toInt(),24,0x668BA9D8);elevation=dp(6).toFloat()}
    private fun labelCard(s:String)=glassCard().apply{setPadding(dp(16),dp(15),dp(16),dp(15));addView(label(s,13f,muted,false))}
    private fun label(s:String,sz:Float,c:Int,b:Boolean)=TextView(this).apply{text=s;textSize=sz;setTextColor(c);if(b)typeface=Typeface.DEFAULT_BOLD}
    private fun iconButton(s:String,action:()->Unit)=TextView(this).apply{text=s;textSize=24f;gravity=Gravity.CENTER;setTextColor(blue);background=rounded(0xDFFFFFFF.toInt(),18,0x668BA9D8);setOnClickListener{action()}}
    private fun actionButton(s:String,action:()->Unit)=TextView(this).apply{text=s;textSize=16f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=rounded(blue,18,0xFF8CB5FF.toInt());setOnClickListener{action()};elevation=dp(4).toFloat()}
    private fun rounded(c:Int,r:Int,stroke:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat();setStroke(dp(1),stroke)}
    private fun weight(margin:Boolean=false)=LinearLayout.LayoutParams(0,dp(112),1f).apply{if(margin)leftMargin=dp(10)}
    private fun gap(h:Int){page.addView(View(this),LinearLayout.LayoutParams(1,dp(h)))}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
